#ifndef ROTATESPRITE__H
#define ROTATESPRITE__H

#include "multisprite.h"

class rotateSprite : public MultiSprite {
public:
    rotateSprite(const std::string&);

    virtual void draw() const;
    virtual void update(Uint32 ticks);

protected:
rotateSprite(const rotateSprite&);
    rotateSprite& operator=(const rotateSprite&);
};

#endif
