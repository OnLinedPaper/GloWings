#ifndef PICKUPSPRITE__H
#define PICKUPSPRITE__H

#include "multisprite.h"

class pickupSprite : public MultiSprite {
public:
    pickupSprite(const std::string&, const Vector2f&);

    virtual void draw() const;
    virtual void update(Uint32 ticks);

    bool getSelfDestructed() const { return selfDestructed; }

protected:
    pickupSprite(const pickupSprite&);
    pickupSprite& operator=(const pickupSprite&);

    int timeToLive;
    bool selfDestructed;
};

#endif
