#include "rotateSprite.h"
#include "gamedata.h"
#include "renderContext.h"

rotateSprite::rotateSprite( const std::string& name ) :
    MultiSprite(name)
{ }

rotateSprite::rotateSprite(const rotateSprite& s) :
    MultiSprite(s)
{ }

rotateSprite& rotateSprite::operator=(const rotateSprite& s) {
    Drawable::operator=(s);
    return *this;
}

void rotateSprite::draw() const {
  	images[currentFrame]->drawRotate(getX(), getY(), getScale(),
        getScaledWidth(), getScaledHeight(), getVelocityX(), getVelocityY());
}

void rotateSprite::update(Uint32 ticks) {
	MultiSprite::update(ticks);
}
