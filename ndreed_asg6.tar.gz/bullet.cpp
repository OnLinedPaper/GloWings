#include <iostream>
#include <cmath>
#include "bullet.h"

Bullet& Bullet::operator=(const Bullet& b) {
    this->distance = b.distance;
    this->maxDistance = b.maxDistance;
    this->accel = b.accel;
    this->elapsedTicks = b.elapsedTicks;
    this->maxTicks = b.maxTicks;
    this->tooLong = b.tooLong;
    return *this;
}

void Bullet::update(Uint32 ticks) {
    Vector2f pos = getPosition();
    rotateSprite::update(ticks);

    setVelocity(getVelocity() * accel);

    distance += ( hypot(getX()-pos[0], getY()-pos[1]) );
    elapsedTicks += ticks;
    if (elapsedTicks > maxTicks || distance > maxDistance) {
        tooLong = true;
    }
}
