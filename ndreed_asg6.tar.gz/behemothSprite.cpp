#include "behemothSprite.h"
#include "gamedata.h"
#include "renderContext.h"
#include "rotateSprite.h"
#include "shieldSprite.h"

behemothSprite::behemothSprite(const std::string& name) :
    MultiSprite(name),
    children(),
    shields(),
    panicRadius(Gamedata::getInstance().
            getXmlInt("behemothAttrs/observerTraits/panicRadius")),
    maxSpeed(Gamedata::getInstance().
            getXmlInt("behemothAttrs/movementTraits/maxSpeed")),
    acceleration(Gamedata::getInstance().
            getXmlInt("behemothAttrs/movementTraits/acceleration")),
    maxShieldCount(Gamedata::getInstance().
        getXmlInt("behemothAttrs/childTraits/shieldCount")),
    shieldCount(0),
    shieldSpawnDelay(Gamedata::getInstance().
        getXmlInt("behemothAttrs/childTraits/shieldSpawnDelay")),
    timeToNextShield(0),
    seekerCount(Gamedata::getInstance().
        getXmlInt("behemothAttrs/childTraits/seekerCount")),
    seekersSpawned(0),
    miteCount(Gamedata::getInstance().
        getXmlInt("behemothAttrs/childTraits/miteCount")),
    mitesSpawned(0)
{
    //4 random possible spawn points
    setX(Gamedata::getInstance().getXmlInt("world/width")
        * ((std::rand() % 2 == 0) ? 1 : 3) / 4);
    setY(Gamedata::getInstance().getXmlInt("world/height")
        * ((std::rand() % 2 == 0) ? 1 : 3) / 4);
}

behemothSprite::behemothSprite(const behemothSprite& s) :
    MultiSprite(s),
    children(s.children),
    shields(s.shields),
    panicRadius(s.panicRadius),
    maxSpeed(s.maxSpeed),
    acceleration(s.acceleration),
    maxShieldCount(s.maxShieldCount),
    shieldCount(s.shieldCount),
    shieldSpawnDelay(s.shieldSpawnDelay),
    timeToNextShield(s.timeToNextShield),
    seekerCount(s.seekerCount),
    seekersSpawned(s.seekersSpawned),
    miteCount(s.miteCount),
    mitesSpawned(s.mitesSpawned)
{ }

behemothSprite& behemothSprite::operator=(const behemothSprite& s) {
    Drawable::operator=(s);
    this->children = s.children;
    this->shields = s.shields;
    this->panicRadius = s.panicRadius;
    this->maxSpeed = s.maxSpeed;
    this->acceleration = s.acceleration;
    this->maxShieldCount = s.maxShieldCount;
    this->shieldCount = s.shieldCount;
    this->shieldSpawnDelay = s.shieldSpawnDelay;
    this->timeToNextShield = s.timeToNextShield;
    this->seekerCount = s.seekerCount;
    this->seekersSpawned = s.seekersSpawned;
    return *this;
}

void behemothSprite::draw() const {
    MultiSprite::draw();
}

void behemothSprite::detachShield(Drawable *o) {
    std::list<Drawable*>::iterator ptr = shields.begin();
    while(ptr != shields.end()) {
        if(*ptr == o) {
            ptr = shields.erase(ptr);
            shieldCount--;
            return;
        }
        ++ptr;
    }
}

void behemothSprite::destroyShields() {
    for(Drawable *s : shields) {
        dynamic_cast<shieldSprite *>(s)->setProtectThisIsAlive(false);
    }
}

const Vector2f behemothSprite::moveAboutPlayer() const {
    //run away from the player

    Vector2f heading(0, 0);
    //distance from the player
    Vector2f dist = getPrecisePlayerPos() - getPrecisePos();

    if(getPlayerIsAlive() &&
        fabs(dist.magnitude()) < panicRadius && dist.magnitude() > 0) {
            //player is too close for comfort

            //adjust heading to flee
            heading -= dist;
            //normalize heading to flee
            heading = heading.normalize() * acceleration;
    }

    if(getHealth() < ((getMaxHealth() * 3) / 4)) {
        //behemoth enters battle mode at 3/4 health and doubles its speed
        heading *= -2;
    }

    return(heading);
}

void behemothSprite::steer(const Vector2f heading) {
    Vector2f speed = getVelocity();

    setVelocity(speed + heading);
    speed = getVelocity();

    if(speed.magnitude() > maxSpeed) {
        setVelocity(speed.normalize() * maxSpeed);
    }
}

void behemothSprite::update(Uint32 ticks) {
    steer(moveAboutPlayer());

    MultiSprite::update(ticks);

    std::list<Drawable*>::iterator ptr = shields.begin();
    while(ptr != shields.end()) {
        (dynamic_cast<shieldSprite *>(*ptr))->setProtectThis(Vector2f(
            getX() + (getScaledWidth() /2),
            getY() + (getScaledHeight() /2)
        ));
        ++ptr;
    }
}
