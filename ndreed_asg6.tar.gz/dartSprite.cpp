#include "dartSprite.h"
#include "gamedata.h"

dartSprite::dartSprite(const std::string& name) :
    rotateSprite(name),

    seekRadius(Gamedata::getInstance().
            getXmlInt("dartAttrs/observerTraits/seekRadius")),
    maxSpeed(Gamedata::getInstance().
            getXmlInt("dartAttrs/movementTraits/maxSpeed")),
    acceleration(Gamedata::getInstance().
            getXmlInt("dartAttrs/movementTraits/acceleration"))
{
    //4 random possible spawn points
    setX(Gamedata::getInstance().getXmlInt("world/width")
        * ((std::rand() % 2 == 0) ? 1 : 3) / 4);
    setY(Gamedata::getInstance().getXmlInt("world/height")
        * ((std::rand() % 2 == 0) ? 1 : 3) / 4);

    //random velocity
    setVelocity(Vector2f(
        std::rand()%(maxSpeed)-maxSpeed/3,
        std::rand()%(maxSpeed)-maxSpeed/3
    ));
}

dartSprite::dartSprite(const dartSprite& s) :
    rotateSprite(s),
    seekRadius(s.seekRadius),
    maxSpeed(s.maxSpeed),
    acceleration(s.acceleration)
{ }

dartSprite& dartSprite::operator=(const dartSprite& s) {
    Drawable::operator=(s);
    this->seekRadius = s.seekRadius;
    this->maxSpeed = s.maxSpeed;
    this->acceleration = s.acceleration;
    return *this;
}

void dartSprite::draw() const {
    rotateSprite::draw();
}

const Vector2f dartSprite::seekPlayer() const {
    //divebomb the player!

    Vector2f heading(0, 0); //distance from the player

    Vector2f dist = getPrecisePlayerPos() - getPrecisePos();

    if(getPlayerIsAlive() &&
        fabs(dist.magnitude()) < seekRadius && dist.magnitude() > .001) {
            //player is within seek radius

            //adjust heading to intercept
            heading += dist;
            //normalize heading to intercept
            heading = heading.normalize() * acceleration;
    }

    return(heading);
}

void dartSprite::steer(const Vector2f heading) {
    Vector2f speed = getVelocity();

    setVelocity(speed + heading);
    speed = getVelocity();

    if(speed.magnitude() > maxSpeed) {
        setVelocity(speed.normalize() * maxSpeed);
    }
}

void dartSprite::update(Uint32 ticks) {
    steer(seekPlayer());
    rotateSprite::update(ticks);
}
