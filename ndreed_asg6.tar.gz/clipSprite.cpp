//the clipSprite is designed to clip an image down. at present it only clips
//from the left, i.e. the left side of a sprite is consumed

#include "clipSprite.h"
#include "gamedata.h"
#include "renderContext.h"

clipSprite::clipSprite(const std::string& name) :
    MultiSprite(name),
    clipPct(0)
{ }

clipSprite::clipSprite(const clipSprite& s) :
    MultiSprite(s),
    clipPct(s.clipPct)
{ }

clipSprite& clipSprite::operator=(const clipSprite& s) {
    Drawable::operator=(s);
    this->clipPct = s.clipPct;
    return *this;
}

void clipSprite::draw() const {
    
}

void clipSprite::update(Uint32 ticks) {
    MultiSprite::update(ticks);
}
