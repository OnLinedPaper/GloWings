#ifndef CLIPSPRITE__H
#define CLIPSPRITE__H

#include "multisprite.h"

class clipSprite : public MultiSprite {
public:
    clipSprite(const std::string&);
    clipSprite(const clipSprite&);

    virtual void draw() const;
    virtual void update(Uint32 ticks);

    void setClipPct(float p) {clipPct = p;}
    float getClipPct() {return clipPct;}

protected:
    clipSprite& operator=(const clipSprite&);

    float clipPct;
};

#endif
